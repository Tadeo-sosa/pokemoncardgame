import flet as ft
import httpx
import tkinter as tk
from tkinter import filedialog

SERVER_URL = "http://127.0.0.1:8001"


async def main(page: ft.Page):
    page.title = "🎨 PokéDraw"
    page.padding = 20
    page.scroll = ft.ScrollMode.AUTO
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    selected_file = {"path": None}

    # ---------------- IMAGE ----------------
    img_preview = ft.Image(
        src="",
        width=300,
        height=300,
        visible=False,
    )

    result_txt = ft.Text(size=18)

    status = ft.Text(
        "👉 Seleccioná una imagen"
    )

    # ---------------- MAZO ----------------
    deck_area = ft.Column(
        visible=False,
        spacing=10,
    )

    # ---------------- SELECCIONAR IMAGEN ----------------
    def pick_file(e):
        root = tk.Tk()
        root.withdraw()

        file_path = filedialog.askopenfilename(
            title="Seleccionar imagen",
            filetypes=[
                ("Imágenes", "*.png *.jpg *.jpeg")
            ]
        )

        root.destroy()

        if file_path:
            selected_file["path"] = file_path

            img_preview.src = file_path
            img_preview.visible = True

            send_btn.disabled = False

            status.value = "✅ Imagen seleccionada"

            page.update()

    # ---------------- ENVIAR ----------------
    async def send_image(e):
        if not selected_file["path"]:
            status.value = "❌ Seleccioná una imagen"
            page.update()
            return

        try:
            status.value = "📡 Enviando..."
            page.update()

            with open(selected_file["path"], "rb") as f:
                image_bytes = f.read()

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    f"{SERVER_URL}/upload",
                    files={
                        "file": (
                            "image.jpg",
                            image_bytes,
                            "image/jpeg"
                        )
                    }
                )

            data = response.json()

            result_txt.value = (
                f"🎴 Pokémon: {data['pokemon']}\n"
                f"❤️ HP: {data['hp']}\n"
                f"⚔️ ATK: {data['attack']}\n"
                f"🎯 Similitud: {data['similarity']*100:.1f}%"
            )

            status.value = "✅ Carta enviada"

        except Exception as ex:
            status.value = f"❌ Error: {str(ex)}"

        page.update()

    # ---------------- VER MAZO ----------------
    async def show_deck(e):
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{SERVER_URL}/deck"
                )

            data = response.json()

            cards = data["cards"]

            deck_area.controls.clear()

            if len(cards) == 0:
                deck_area.controls.append(
                    ft.Text("🃏 Mazo vacío")
                )

            else:
                for card in reversed(cards):
                    deck_area.controls.append(
                        ft.Container(
                            content=ft.Column(
                                [
                                    ft.Text(
                                        card["pokemon"],
                                        size=20,
                                        weight=ft.FontWeight.BOLD,
                                    ),

                                    ft.Text(
                                        f"❤️ HP: {card['hp']}"
                                    ),

                                    ft.Text(
                                        f"⚔️ ATK: {card['attack']}"
                                    ),

                                    ft.Text(
                                        f"🎯 {card['similarity']*100:.1f}%"
                                    ),
                                ]
                            ),
                            padding=10,
                            border_radius=10,
                            bgcolor="#f0f0f0",
                        )
                    )

            deck_area.visible = True

            status.value = "✅ Mazo cargado"

        except Exception as ex:
            status.value = f"❌ Error mazo: {str(ex)}"

        page.update()

    # ---------------- OCULTAR MAZO ----------------
    def hide_deck(e):
        deck_area.visible = False
        page.update()

    # ---------------- BOTONES ----------------
    btn_pick = ft.Button(
        "📁 Seleccionar imagen",
        on_click=pick_file,
    )

    send_btn = ft.Button(
        "📤 Enviar imagen",
        on_click=send_image,
        disabled=True,
    )

    btn_deck = ft.Button(
        "🃏 Ver mazo",
        on_click=show_deck,
    )

    btn_hide = ft.Button(
        "❌ Ocultar mazo",
        on_click=hide_deck,
    )

    # ---------------- UI ----------------
    page.add(
        ft.Text(
            "🎨 PokéDraw",
            size=30,
            weight=ft.FontWeight.BOLD,
        ),

        btn_pick,

        img_preview,

        send_btn,

        result_txt,

        status,

        ft.Row(
            [btn_deck, btn_hide],
            alignment=ft.MainAxisAlignment.CENTER,
        ),

        deck_area,
    )


ft.run(main)